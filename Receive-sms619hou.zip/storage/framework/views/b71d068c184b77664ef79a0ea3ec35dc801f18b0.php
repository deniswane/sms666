
<?php if(count($numbers)>0): ?>
    <?php $__currentLoopData = $numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="Cell">
            <a href="#">
            <div><?php echo e($num->province); ?><br>
                

                
                    
                    <img src="<?php echo e($num->src); ?>" alt=""
                         style="vertical-align: middle;">&nbsp;&nbsp;
                    <?php
                    echo preg_replace("/[^\.]{1,3}$/","****",$num->phone);
                    ?>
                    </br>

                <strong> SMS received:<?php echo e($num->amount); ?>

                    <section
                            style="border:none; height: auto; padding: 1px; width: auto; background: #33FF66;">
                    </section>
                </strong>
            </div>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>