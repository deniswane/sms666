<?php echo $content; ?>

