<ul class="topnav">

    <?php if(auth()->guard()->guest()): ?>
        <li><a href="<?php echo e(route('login')); ?>"><?php echo e(trans('home.login')); ?></a></li>
        <?php elseif(Auth::user()->isVerified()): ?>

            <li>
                <a id="hover" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                   document.getElementById('logout-form').submit();">Logout
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>

            </li>

            <li><a id="" href="#"><?php echo e(Auth::user()->name); ?></a></li>
        <?php else: ?>

            <?php echo e(Auth::logout()); ?>

            <li><a href="<?php echo e(route('login')); ?>"><?php echo e(trans('home.login')); ?></a></li>

            <script>
                layui.use('layer', function () {
                    var layer = layui.layer;
                    layer.alert('Please login to your mailbox to complete the activation and registration !', {
                        title: 'msg',
                        btn: 'ok',
                        icon: 6,
                        skin: 'layer-ext-moon'
                    })
                });

            </script>
            <?php endif; ?>
            <li><select id="formLanguage" onchange="location = this.value;">
                    <option value="?lan=en">language</option>

                    <option value="/?lan=zh-CN"  >简体中文</option>
                    <option value="?lan=en">English</option>
                </select></li>


        <li><a href="javascript:void(0)" onclick="myTab()"><?php echo e(trans('home.private_numbers')); ?></a></li>


            <li><a href="<?php echo e(route('home')); ?>"><?php echo e(trans('home.home')); ?></a></li>
            <li class="icon"><a href="javascript:void(0);" onclick="myFunction()">&#9776;</a></li>
            <li><a href="#"><img id="android_img"
                                 src="/img/android-app_google-play_button.png"
                                 alt="Android App"
                                 style="height: 35px; margin-top: -12px;"></a>
            </li>

</ul>

<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script>

    //JavaScript代码区域
    layui.use('layer', function () {
        var layer = layui.layer;

    });

    function myTab() {

        $.ajax({
            type: 'get',
            url: "<?php echo e(route('getprice')); ?>",
            data: '',
            cache: false,
            success: function (data) {

                layer.tab({
                    area: ['35%', '55%'],
                    tab: [{
                        title: 'API',
                        content: '<p "><strong style="font-size: 18px;">Address</strong><br/>' +
                        '1.Set keywords :</br>http://sms-receive-online.info/manager/api/keyword?k=k1:k2&token=Your token<br/>'+
                        '2.Get phone number :</br>http://sms-receive-online.info/manager/api/getPhoneNumber?token=Your token<br/>'+
                        '3.Get content :</br>http://sms-receive-online.info/manager/api/getSmsContent?token=Your token&phone=The phone number obtained from the second step <br/><strong style="font-size: 18px;">Response</strong><br/>' +
                        '{"code":200,"msg":"success"}<br/>{"code":201,"msg":"Please update your text message first"}<br/>{"code":102,"msg":"Format error"}<br/>' +
                        '{"code":401,"msg":"No new text messages"}<br/>' +
                        '{"code":103,"msg":"The frequency is too fast"}<br/>' +
                        '{"code":105,"msg":"Sorry, sir. You have no right to visit"}<br/>' +
                        '{"code":106,"msg":"You need to charge money"}<br/>' +
                        '{"code":107,"msg":"No mobile phone number for the time being"}<br/><table></table></p>'
                    }, {
                        title: 'Price',
                        content:
                        "<p ><strong style='font-size: 18px;'>Price</strong><br/> "+data.price+
                        "  USD/time<p><strong <strong style='font-size: 18px;'>Your token</strong><br/>"+
                        "<?php if(auth()->guard()->guest()): ?> Please register and log in <?php else: ?><?php echo e(Auth::user()->token); ?> <?php endif; ?><br/>"+
                        "<strong <strong style='font-size: 18px;'>Your balance</strong><br/>"+
                        "<?php if(auth()->guard()->guest()): ?>  <?php else: ?><?php echo e(Auth::user()->balance); ?>USD <?php endif; ?>"

                    
                        
                        
                        
                         
                        
                    }
                    ]
                });
                 
                    
                        
                        
                        
                        
                        
                        
                            
                        
                        
                            
                                
                            
                                
                            
                        
                        
                        
//                    })

//                })
            },
            error: function () {
            }
        });
    }

</script>

