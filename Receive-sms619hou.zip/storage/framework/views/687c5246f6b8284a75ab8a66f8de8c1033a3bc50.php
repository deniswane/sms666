
<html>
<head>
    <meta charset="utf-8">
    <title>layui</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="//res.layui.com/layui/dist/css/layui.css"  media="all">
    <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->
    <script type="text/javascript" src="/static/admin/js/jquery.min.js"></script>

</head>
<body>

<form class="layui-form" action=""  lay-filter="example">



    <div class="layui-form-item">
        <label class="layui-form-label">姓名</label>
        <div class="layui-input-block">
            <input type="text" name="username" id="username" lay-verify="title" autocomplete="off" placeholder="请输入标题" value="<?php echo e($user->name); ?>" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">邮箱</label>
        <div class="layui-input-block">
            <input type="text" name="email" id="email" lay-verify="title" autocomplete="off" placeholder="请输入标题" value="<?php echo e($user->email); ?>" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn" lay-submit="" onclick="submit_data()" lay-filter="demo1">立即提交</button>
        </div>
    </div>
</form>

</body>
</html>
<script>
    function submit_data() {
//        alert('66')
        name = $('#username').val();
        amail = $('#email').val();
        $.ajax({
            type: 'post',
            url: "<?php echo e(route('index.edit')); ?>",
            cache: false,
            data: {name:name,email:amail,_token:"<?php echo e(csrf_token()); ?>",id:"<?php echo e($user->id); ?>"},
            success: function (data) {
//                console.log(data)
                alert('666')
                self.close()
                window.opener.close();
            },
            error:function (data) {
            layer.alert(data.msg)

        }
        });
    }

    
        
        

                
                    
                    
                    
                    
                    
                        

                        
                        
                            
                        
                            
                                
                            
                        
                    
                    
                        

                    
                


        
    
</script>