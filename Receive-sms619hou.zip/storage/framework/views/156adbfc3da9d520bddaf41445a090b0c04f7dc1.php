<div id="bottom_footer" align="center"><a href="/">sms-receive-online</a> |  Copyright &copy; <?php echo e(date('Y',time())); ?>

         <?php if($lang == 'zh-CN'): ?>
                <a target="_blank" href=""><img
                                style="vertical-align: middle;"  src="/img/zhifubao.jpg" title="zhifubao" width="98"
                                height="42"/></a>
         <?php else: ?>
                <a target="_blank" href="https://www.paypal.com/c2/webapps/mpp/home"><img
                                style="vertical-align: middle;"  src="/img/paypal-logo.svg" title="We accept Paypal" width="98"
                                height="42"/></a>
         <?php endif; ?>

</div>