<?php if(count($contents)>0): ?>
    <table id="msgs" align="center">
        <tr>
            <th width="auto">From</th>
            <th width="auto">SMS Messages</th>
            <th width="auto">Added</th>
            <th width="auto" rowspan="15">
                
                
                     
                     
                     
            </th>
        </tr>
        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td data-label="From   :">
                    <?php
                        echo preg_match('/\d/is', $con->from) ? preg_replace("/[^\.]{1,3}$/","xxxx",$con->from) : $con->from  ;
                    ?>
                </td>
                <td id="divhid1" data-label="Message:"><?php echo e($con->content); ?></td>
                <td data-label="Added:"><?php echo e($con->updated_at->diffForHumans()); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>