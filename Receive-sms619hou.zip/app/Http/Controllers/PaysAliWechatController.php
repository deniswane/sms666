<?php

namespace App\Http\Controllers;

use App\Invoice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Yansongda\LaravelPay\Facades\Pay;


class PaysAliWechatController extends Controller
{
    /**支付
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function alipay(Request $request)
    {
        if ($request->isMethod('post')) {
            $post = $request->post();
            $validator = Validator::make($post, [
                'prices' => 'numeric|required',
            ]);
            if ($validator->fails()) {
                return back();
            }
            if ($post['prices'] == 0) {
               return redirect()->back();
            }
            $time = microtime(true);
            list($s1,$s2) = explode('.', $time);
            $order_no = date("YmdHis") . $s2 . rand(1000,9999);
            $config_biz = [
                //商家订单
                'out_trade_no' => $order_no,
                'total_amount' =>$post['prices'] ,
                'subject' => '短信平台支付',
            ];
            return Pay::alipay()->web($config_biz);

        }else{
            return redirect()->back();
        }
    }

    /**同步通知
     * @param Request $request
     * @return mixed
     */
    public function alireturn(Request $request)
    {
        return Pay::alipay()->verify($request->all());

    }

    /**异步通知 更新数据
     * @param Request $request
     */
    public function alinotify(Request $request)
    {

        if (Pay::alipay()->verify($request->all())) {

                $invoices = new Invoice();
                $invoices->merchant_message='';
                $invoices->commodity_escription='';
                $invoices->feedback='';
                $invoices->invoices=$request->out_trade_no;
                $invoices->money=$request->total_amount;
                $invoices->paid='';
                $invoices->save();

                $user=User::find(Auth::user()->id);
                $user->balance = $user->balance +$request->total_amount;
                $user->save();

//            file_put_contents(storage_path('notify.txt'), "收到来自支付宝的异步通知\r\n", FILE_APPEND);
//            file_put_contents(storage_path('notify.txt'), '订单号：' . $request->out_trade_no . "\r\n", FILE_APPEND);
//            file_put_contents(storage_path('notify.txt'), '订单金额：' . $request->total_amount . "\r\n\r\n", FILE_APPEND);
        } else {
            file_put_contents(storage_path('notify.txt'), "收到异步通知\r\n", FILE_APPEND);
        }

        return view('paypal.success');
//       echo "success";
    }

}
