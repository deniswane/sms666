<?php
echo __FILE__; // 取得当前文件的绝对地址，结果：D:\www\test.php
echo dirname(__FILE__); // 取得当前文件所在的绝对目录，结果：D:\www\

