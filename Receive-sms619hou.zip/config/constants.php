<?php
//namespace  ssss;
////$price = \Illuminate\Support\Facades\DB::table('prices')->find(1);
//return [
//    'PRICE' => '1',
//];