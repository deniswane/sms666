<center>
<br><br>
<h1 style="color:red;">在进行付款时发生错误!</h1>
<br>
<br>
<img src="{{ URL::asset('img/error.png') }}">

    <br>

    <a href="{{ route('home') }}">返回首页</a>

</center>