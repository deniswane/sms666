<?php $__env->startSection('content'); ?>
    <div class="panel">
        <h5><strong><?php echo e(trans('home.subtitle_1')); ?></strong><br>
            <?php echo e(trans('home.received_email')); ?><br>
            <strong><?php echo e(trans('home.subtitle_2')); ?></strong><br>
            <?php echo e(trans('home.subtitle_2_con')); ?><br>
        </h5>
        <div align="center">
            <div class='login'></div>
            <div class="Table">

                <div class="Row">
                    <?php echo $__env->make('shared._cell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        <br>
        <?php if(auth()->guard()->guest()): ?>
        <?php else: ?>
        Please enter the amount in the input box and click on the purchase
        <form style="margin: 20px 5px;" method="post" >
            <input type="text" placeholder=""  id="pri" autofocus  class="ec_input">USD
            <input style="display:none" >
            <img id="submitAdd" style="cursor:pointer" src="/img/btn_buynow.gif" alt="PayPal - The safer, easier way to pay online!">
        </form>

            <script>

            $("#submitAdd").click(function() {
                $.ajax({
                    type: 'post',
                    url: "<?php echo e(route('ec-checkout')); ?>",
                    cache: false,
                    data: {'_token': "<?php echo e(csrf_token()); ?>", 'prices': $('#pri').val()},
                    dataType: 'json',
                    beforeSend: function () {
                        layer.msg('Loading...', {
                            icon: 16,
                            shade: [0.5, '#f5f5f5'],
                            scrollbar: false,
                            offset: '50%',
                            time: 300000
                        });
                    },
                    success: function (data) {
                        if (data.code == '1') {
                            layer.alert('Incomplete filling format', {btn: 'OK'});
                        } else if (data.code == 200) {
                            $(location).attr('href', data.msg);
                        }
                    },
                    error: function (data) {
                        console.log(data)
                    }
                });
            })
            </script>

            <?php endif; ?>
<div align="left">
<h5><strong>• <?php echo e(trans('home.subtitle_3')); ?> ?</strong>
<br>
<strong><?php echo e(config('app.name')); ?></strong> <?php echo e(trans('home.subtitle_3_con')); ?><br>
<br>
<strong> • </strong><?php echo e(trans('home.subtitle_4')); ?><br>
<br>
<strong><?php echo e(trans('home.subtitle_5')); ?></strong><br>
<?php echo e(trans('home.subtitle_4_con')); ?><br>
<br>
<strong><?php echo e(trans('home.subtitle_6')); ?></strong><br>
<?php echo e(trans('home.subtitle_6_con')); ?><br>
<br>
<strong><?php echo e(trans('home.subtitle_7')); ?></strong><br>
<?php echo e(trans('home.subtitle_7_con')); ?><br>
<br>
<strong><?php echo e(trans('home.subtitle_8')); ?></strong><br>
<?php echo e(trans('home.subtitle_8_con')); ?><br>
<br>
<strong> <?php echo e(trans('home.subtitle_9')); ?></strong><br>
<?php echo e(trans('home.subtitle_9_con')); ?><br>
<br>
<strong> <?php echo e(trans('home.subtitle_10')); ?></strong><br>
<?php echo e(trans('home.subtitle_10_con')); ?><br>
<br>
</h5>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>