
<?php $__env->startSection('title','用户余额'); ?>

<script src="/js/echarts.common.min.js"></script>
<script src="http://momentjs.cn/downloads/moment.js"></script>
<?php $__env->startSection('content'); ?>
    
        
        
            
            
            
            
            
            
            
        
        
    

    <!-- 为ECharts准备一个具备大小（宽高）的Dom -->
    <div id="main" style="width: 600px;height:400px;"></div>
    <script type="text/javascript">
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('main'));

        // 指定图表的配置项和数据
        var option = {
            title: {
                text: '折线图堆叠'
            },
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['邮件营销', '联盟广告']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: {}
                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
            },
            yAxis: {
                type: 'value'
            },
            series: [
                {
                    name: '邮件营销',
                    type: 'line',
                    stack: '总量',
                    data: [120, 132, 101, 134, 90, 230, 210]
                },
                {
                    name: '联盟广告',
                    type: 'line',
                    stack: '总量',
                    data: [220, 182, 191, 234, 290, 330, 310]
                }

            ]
        };

        
        myChart.setOption(option);
    </script>
    <div id="reportrange"><span></span></div>
    <script src="/js/daterangepicker.js"></script>

    <script>
        $(function () {
            /*设置开始结束时间*/
            var start = moment().subtract(30, 'days');
            var end = moment().subtract(-1,'day');
            var datas = {};
            /*选择之后，将时间重新赋值input*/
            function cb(start, end) {
                $('#reportrange span').html(start.format('YYYY/MM/DD') + ' - ' + end.format('YYYY/MM/DD'));
            }
            $('#reportrange').daterangepicker({
                startDate: start,
                endDate: end,
                /*本地化数据*/
                locale: {
                    "format": "YYYY/MM/DD",
                    "separator": " - ",
                    "applyLabel": "应用",
                    "cancelLabel": "关闭",
                    "fromLabel": "From",
                    "toLabel": "至",
                    "customRangeLabel": "自定义",
                    "weekLabel": "W",
                    "daysOfWeek": ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"
                    ],
                    "monthNames": ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"
                    ],
                    "firstDay": 1
                },
                ranges: {
                    '今天': [moment(), moment().subtract(-1, 'days')],
                    '昨天': [moment().subtract(1, 'days'), moment()],
                    '前7天': [moment().subtract(7, 'days'), moment()],
                    '前30天': [moment().subtract(30, 'days'), moment()],
                    '本月': [moment().startOf('month'), moment().endOf('month').subtract(-1,'day')],
                    '上月': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month').subtract(-1,'day')],
                    '所有': [moment("2017-09-25"), moment().subtract(-1, 'days')]
                }
            }, cb);

            cb(start, end);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index.lay', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>