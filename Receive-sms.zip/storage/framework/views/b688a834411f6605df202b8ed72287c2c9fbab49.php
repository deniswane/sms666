<?php $__env->startSection('title', 'Detail'); ?>
<?php $__env->startSection('content'); ?>
    <div class="panel">
        <h4 style="text-align:center;"> List of SMS messages received for phone number : <strong>
                <?php
                    echo preg_replace("/[^\.]{1,3}$/","****",$number->phone);
                ?>
                :
                <?php echo e($number->country); ?> </strong></h4>

        <h5>
<span class="alert-box [secondary radius round]">
- Message will appear on this page within seconds after we receive.<br>
- Received messages are displayed as such, does not change anything.<br>
- We do not send response to incoming SMS.<br>
- This is the list of the last 200 messages received on this number.<br>
<span class="text-right">SMS received today:
    <?php
      echo  rand(1,$number->amount);
    ?><br>
Time of use:
    <?php
        echo  rand(1,60);
    ?>
     days<br>
Availability: <b class="statut_online">online</b></span><br><br>
<div align="center"><button class="autorefresh"
                            onClick="window.location.reload();">Refresh Webpage</button></div></span></h5>
        <?php echo $__env->make('shared._sms_content_cell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </label>
        <script type="text/javascript">


            $(window).load(function () {
                null == document.getElementsByTagName("iframe").item(ga.length - 1) && $("div.login:last").html('<p class="alert-box [secondary warning radius round]">We&apos;ve detected that you&apos;re using <strong>AdBlock Plus</strong> or some other adblocking software. Please be aware that this is only contributing to the demise of the site. We need money to operate the site, and almost all of that comes from our online advertising. Please disable <strong>AdBlock Plus</strong> and refresh webpage!</p>') && $('#msgs').html('')
            });

        </script>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>