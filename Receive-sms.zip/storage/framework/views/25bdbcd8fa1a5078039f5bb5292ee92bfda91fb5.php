
<?php $__env->startSection('title','用户信息'); ?>
<?php $__env->startSection('content'); ?>
    <table class="layui-table" >
        <thead>
        <tr>
            <td>序列号</td>
            <td>信息</td>
            <td>来源</td>
            <td>目标用户</td>
            <td>时间</td>
        </tr>

        </thead>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index.lay', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>