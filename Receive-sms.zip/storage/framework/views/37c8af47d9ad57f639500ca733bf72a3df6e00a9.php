<?php echo $content; ?>

