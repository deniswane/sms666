<div id="social">
    <ul>
        <li><a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.receive-sms-online.info" target="_blank"><img src="img/Facebook%20Round.png" alt="Share on FaceBook" title="Share on FaceBook" height="20" width="20"></a></li>
        <li><a href="https://twitter.com/share?url=http%3A%2F%2Fwww.receive-sms-online.info" target="_blank"><img src="img/Twitter%20round.png" alt="Tweet" title="Tweet" height="20" width="20"></a></li>
        <li><a href="https://plus.google.com/share?url=http%3A%2F%2Fwww.receive-sms-online.info" target="_blank"><img src="img/Google%20plus%20round.png" alt="Google+" title="Google+" height="20" width="20"></a></li>
        <li><a href="https://www.linkedin.com/cws/share?url=http%3A%2F%2Fwww.receive-sms-online.info" target="_blank"><img src="img/Linkedin%20round.png" alt="LinkedIn" title="LinkedIn" height="20" width="20"></a></li>
        <li><a href="https://www.pinterest.com/pin/create/button/?url=http%3A%2F%2Fwww.receive-sms-online.info" target="_blank"><img src="img/Pinterest%20round.png" alt="Pin It" title="Pin It" height="20" width="20"></a></li>
        <li><a href="https://www.tumblr.com/share" title="Share on Tumblr" target="_blank"><img src="img/Tumblr%20round.png" alt="Share on Tumblr" title="Share on Tumblr" height="20" width="20"></a></li>
    </ul>
</div>