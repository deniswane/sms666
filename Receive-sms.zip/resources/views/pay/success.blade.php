<center>
<br><br>
<h1 style="color:green;">您付款成功了!</h1>
<br>
<br>
<img src="{{ URL::asset('img/success.png') }}">
<br>

<a href="{{ route('home') }}">返回首页</a>
</center>