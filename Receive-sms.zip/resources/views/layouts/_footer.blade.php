<div id="bottom_footer" align="center"><a href="/">sms-receive-online</a> |  Copyright &copy; 2018
        <a target="_blank" href="https://www.paypal.com/c2/webapps/mpp/home"><img
                        style="vertical-align: middle;" src="/img/paypal-logo.svg" title="We accept Paypal" width="98"
                        height="42"/></a></a>
</div>